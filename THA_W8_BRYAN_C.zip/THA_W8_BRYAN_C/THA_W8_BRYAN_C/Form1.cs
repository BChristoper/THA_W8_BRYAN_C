﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace THA_W8_BRYAN_C
{
    public partial class Form1 : Form
    {
        string connectionString = "server=localhost;uid=root;pwd=AniazoExodus12!;database=premier_league ; ";

        DataTable dtPlayer = new DataTable();
        DataTable dataX = new DataTable();
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlAdapter;
        string sqlQuery;
        DataTable dt;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            sqlConnect = new MySqlConnection(connectionString);
            sqlQuery = "SELECT team_id, team_name FROM premier_league.team;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "team_id";
            comboBox1.DisplayMember = "team_name";
            int maxWidth = comboBox1.Items.Cast<DataRowView>().Max(item => TextRenderer.MeasureText(item[0].ToString(), comboBox1.Font).Width);
            comboBox1.DropDownWidth = maxWidth;
            comboBox1.Text = "";
            comboBox2.Text = "";
        }

        private void playerDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowLabel.Text = "Player Name: " + "\nTeam Name: " + "\nPlayer Position: " + "\nPlayer Nationality: " + "\nPlayer Number: " +  "\nYellow Cards: " +  "\nRed Cards: " + "\nGoal Scored: " + "\nPenalty Missed: ";
            comboBox1.Text = "";
            comboBox2.Text = "";
        }

        private void findMatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(); // create an instance of the form
            form2.Show(); // show the form
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPlayer = new DataTable();
            sqlQuery = "SELECT p.player_name as `Player Name` FROM player p INNER JOIN team t ON p.team_id = t.team_id AND t.team_id = '" + comboBox1.SelectedValue + "';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtPlayer);
            comboBox2.DataSource = dtPlayer;
            comboBox2.ValueMember = "Player Name";
            comboBox2.SelectedValue = " ";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataX = new DataTable();
            sqlQuery = "SELECT p.player_name AS 'Player Name', t.team_name AS 'Team', p.playing_pos AS 'Position', n.nation AS 'Nationality', p.team_number AS 'Player Number' ," + "sum(if(type = 'CY', 1,0)) AS 'Yellow Cards', sum(if(type = 'CR',1,0)) AS 'Red Cards', sum(if(type = 'GO',1,0)) AS 'Goal Scored', sum(if(type = 'PM',1,0)) AS 'Penalty Missed'" + "\r\nFROM player p\r\nINNER JOIN nationality n ON p.nationality_id = n.nationality_id\r\nINNER JOIN team t ON t.team_id = p.team_id \r\nLEFT JOIN dmatch d ON p.player_id = d.player_id\r\n WHERE p.player_name = '" + comboBox2.SelectedValue + "' GROUP BY 1, 2, 3, 4, 5;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dataX);

            string data = "";
            foreach (DataRow row in dataX.Rows)
            {
                data += "Player Name: " + row["Player Name"].ToString() + "\nTeam Name: " + row["Team"].ToString() +"\nPlayer Position: " + row["Position"].ToString() +
                        "\nPlayer Nationality: " + row["Nationality"].ToString() +"\nPlayer Number: " + row["Player Number"].ToString() +"\nYellow Cards: " + row["Yellow Cards"].ToString() +
                        "\nRed Cards: " + row["Red Cards"].ToString() + "\nGoal Scored: " + row["Goal Scored"].ToString() + "\nPenalty Missed: " + row["Penalty Missed"].ToString();
            }

            ShowLabel.Text = data;

        }
    }
}
