﻿namespace THA_W8_BRYAN_C
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewAway = new System.Windows.Forms.DataGridView();
            this.dataGridViewHome = new System.Windows.Forms.DataGridView();
            this.dataGridViewDetails = new System.Windows.Forms.DataGridView();
            this.comboBoxTeam = new System.Windows.Forms.ComboBox();
            this.comboBoxMatch = new System.Windows.Forms.ComboBox();
            this.ChooseTeam = new System.Windows.Forms.Label();
            this.ChooseMatch = new System.Windows.Forms.Label();
            this.ButtonSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAway)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewAway
            // 
            this.dataGridViewAway.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAway.Location = new System.Drawing.Point(495, 39);
            this.dataGridViewAway.Name = "dataGridViewAway";
            this.dataGridViewAway.RowHeadersWidth = 51;
            this.dataGridViewAway.RowTemplate.Height = 24;
            this.dataGridViewAway.Size = new System.Drawing.Size(293, 202);
            this.dataGridViewAway.TabIndex = 0;
            // 
            // dataGridViewHome
            // 
            this.dataGridViewHome.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHome.Location = new System.Drawing.Point(156, 39);
            this.dataGridViewHome.Name = "dataGridViewHome";
            this.dataGridViewHome.RowHeadersWidth = 51;
            this.dataGridViewHome.RowTemplate.Height = 24;
            this.dataGridViewHome.Size = new System.Drawing.Size(293, 202);
            this.dataGridViewHome.TabIndex = 1;
            // 
            // dataGridViewDetails
            // 
            this.dataGridViewDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDetails.Location = new System.Drawing.Point(156, 262);
            this.dataGridViewDetails.Name = "dataGridViewDetails";
            this.dataGridViewDetails.RowHeadersWidth = 51;
            this.dataGridViewDetails.RowTemplate.Height = 24;
            this.dataGridViewDetails.Size = new System.Drawing.Size(632, 185);
            this.dataGridViewDetails.TabIndex = 2;
            // 
            // comboBoxTeam
            // 
            this.comboBoxTeam.FormattingEnabled = true;
            this.comboBoxTeam.Location = new System.Drawing.Point(12, 74);
            this.comboBoxTeam.Name = "comboBoxTeam";
            this.comboBoxTeam.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTeam.TabIndex = 3;
            this.comboBoxTeam.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBoxMatch
            // 
            this.comboBoxMatch.FormattingEnabled = true;
            this.comboBoxMatch.Location = new System.Drawing.Point(12, 167);
            this.comboBoxMatch.Name = "comboBoxMatch";
            this.comboBoxMatch.Size = new System.Drawing.Size(121, 24);
            this.comboBoxMatch.TabIndex = 4;
            this.comboBoxMatch.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // ChooseTeam
            // 
            this.ChooseTeam.AutoSize = true;
            this.ChooseTeam.Location = new System.Drawing.Point(9, 55);
            this.ChooseTeam.Name = "ChooseTeam";
            this.ChooseTeam.Size = new System.Drawing.Size(93, 16);
            this.ChooseTeam.TabIndex = 5;
            this.ChooseTeam.Text = "Choose Team";
            // 
            // ChooseMatch
            // 
            this.ChooseMatch.AutoSize = true;
            this.ChooseMatch.Location = new System.Drawing.Point(12, 148);
            this.ChooseMatch.Name = "ChooseMatch";
            this.ChooseMatch.Size = new System.Drawing.Size(93, 16);
            this.ChooseMatch.TabIndex = 6;
            this.ChooseMatch.Text = "Choose Match";
            // 
            // ButtonSearch
            // 
            this.ButtonSearch.Location = new System.Drawing.Point(15, 229);
            this.ButtonSearch.Name = "ButtonSearch";
            this.ButtonSearch.Size = new System.Drawing.Size(75, 23);
            this.ButtonSearch.TabIndex = 7;
            this.ButtonSearch.Text = "Search";
            this.ButtonSearch.UseVisualStyleBackColor = true;
            this.ButtonSearch.Click += new System.EventHandler(this.ButtonSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(459, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "VS";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonSearch);
            this.Controls.Add(this.ChooseMatch);
            this.Controls.Add(this.ChooseTeam);
            this.Controls.Add(this.comboBoxMatch);
            this.Controls.Add(this.comboBoxTeam);
            this.Controls.Add(this.dataGridViewDetails);
            this.Controls.Add(this.dataGridViewHome);
            this.Controls.Add(this.dataGridViewAway);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAway)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewAway;
        private System.Windows.Forms.DataGridView dataGridViewHome;
        private System.Windows.Forms.DataGridView dataGridViewDetails;
        private System.Windows.Forms.ComboBox comboBoxTeam;
        private System.Windows.Forms.ComboBox comboBoxMatch;
        private System.Windows.Forms.Label ChooseTeam;
        private System.Windows.Forms.Label ChooseMatch;
        private System.Windows.Forms.Button ButtonSearch;
        private System.Windows.Forms.Label label1;
    }
}