﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace THA_W8_BRYAN_C
{
    public partial class Form2 : Form
    {
        string connectionString = "server=localhost;uid=root;pwd=AniazoExodus12!;database=premier_league ; ";
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlAdapter;
        string sqlQuery;
        DataTable dataX = new DataTable();
        DataTable dataplayers = new DataTable();
        DataTable dtMatchDetails = new DataTable();
        DataTable dtmatch = new DataTable();
        public Form1 rf1 { get; set; }
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            sqlConnect = new MySqlConnection(connectionString);
            sqlQuery = "SELECT team_id, team_name FROM premier_league.team;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dt);
            comboBoxTeam.DataSource = dt;
            comboBoxTeam.ValueMember = "team_id";
            comboBoxTeam.DisplayMember = "team_name";
            int maxWidth = comboBoxTeam.Items.Cast<DataRowView>().Max(item => TextRenderer.MeasureText(item[0].ToString(), comboBoxTeam.Font).Width);
            comboBoxTeam.DropDownWidth = maxWidth;
            comboBoxTeam.Text = "";
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxMatch.DataSource = dtmatch;
            dtmatch = new DataTable();
            sqlQuery = "SELECT concat(t.team_name, \" vs \", t2.team_name) as 'Match', match_id FROM `match` ma INNER JOIN premier_league.referee r ON r.referee_id = ma.referee_id LEFT JOIN premier_league.team t ON ma.team_away = t.team_id LEFT JOIN premier_league.team t2 ON ma.team_home = t2.team_id WHERE t.team_id LIKE '" + comboBoxTeam.SelectedValue + "' OR t2.team_id LIKE '" + comboBoxTeam.SelectedValue + "'";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtmatch);
            comboBoxMatch.DataSource = dtmatch;
            comboBoxMatch.DisplayMember = "Match";
            comboBoxMatch.ValueMember = "match_id";
            comboBoxMatch.SelectedValue = " ";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            var selectedItem = comboBoxMatch.SelectedItem;
            var selectedDataRowView = (DataRowView)selectedItem;
            var displayMemberValue = selectedDataRowView.Row["Match"].ToString();
            string hope = displayMemberValue;
            string[] split = hope.Split(new string[] { " vs " }, StringSplitOptions.None);
            string hometeam = split[0];
            string awayteam = split[1];

            dataplayers = new DataTable();
            sqlQuery = "SELECT t.team_name AS 'Team Name', p.player_name AS 'Player Name' ,  p.playing_pos AS 'Position'\r\nFROM team t , player p\r\nWHERE t.team_id = p.team_id\r\nAND t.team_name = '" + hometeam + "';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dataplayers);
            dataGridViewHome.DataSource = dataplayers;

            dataX = new DataTable();
            sqlQuery = "SELECT t.team_name AS 'Team Name', p.player_name AS 'Player Name' ,  p.playing_pos AS 'Position'\r\nFROM team t , player p\r\nWHERE t.team_id = p.team_id\r\nAND t.team_name = '" + awayteam + "';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dataX);
            dataGridViewAway.DataSource = dataX;

            dtMatchDetails = new DataTable();
            sqlQuery = "SELECT d.minute AS 'Minute', t.team_name AS 'Team Name' , p.player_name AS 'Player Name', if(d.type = 'CY' ,'Yellow Card', if(d.type = 'GO', 'Goal', if(d.type = 'GW', 'Own Goal', if(d.type = 'CR', 'Red Card', if(d.type = 'PM', 'Penalty Miss', 'Goal Penalty'))))) AS 'Type' \r\nFROM dmatch d, team t, player p WHERE d.team_id = t.team_id and p.player_id = d.player_id AND d.match_id = '" + comboBoxMatch.SelectedValue + "';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtMatchDetails);
            dataGridViewDetails.DataSource = dtMatchDetails;
        }

   
    }
}
